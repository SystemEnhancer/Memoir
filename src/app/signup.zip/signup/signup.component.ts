import { Component, OnInit } from '@angular/core';
import {FormsModule} from '@angular/forms'
import {FormBuilder,FormControl,FormGroup,Validators} from '@angular/forms'
import {AuthService} from '../auth.service'

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  signup : FormGroup;

  constructor(public fb:FormBuilder,public authservice:AuthService) {
    this.signup = this.fb.group({
      firstname:['',[Validators.required]],
      lastname:['',[Validators.required]],
      email:['',[Validators.required]],
      password:['',[Validators.required,Validators.minLength(8)]],
      confirmpassword:['',[Validators.required]]
    },{
      validator : this.checkIfMatching("password","confirmpassword")
    })
   }
   checkIfMatching(pass:string,confpass:string)
   {
    return (group:FormGroup)=>{
      let pas = group.controls[pass];
      let cpas = group.controls[confpass];
      if(pas.value==cpas.value)
        return;
      else{
        cpas.setErrors({
          notEqualToPassword : true
        })
      }
    }
   }
  onSubmit(signup)
{
  let email = signup.controls['email'].value
  let password = signup.controls['password'].value
  let firstname = signup.controls['firstname'].value
  let lastname = signup.controls['lastname'].value

  this.authservice.signup(email,password,firstname,lastname).then(()=>{
    alert("You have been successfully signed up! Please log in.")
  }).catch((error)=>{
    console.log(error)
  })
}

  ngOnInit() {
  }

}
